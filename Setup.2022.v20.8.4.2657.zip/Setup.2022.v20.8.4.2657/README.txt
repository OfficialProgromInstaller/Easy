If for some reason the installation does not start, then run the file that is located in the folder named "Fix". 
Good luck to everyone! 😎